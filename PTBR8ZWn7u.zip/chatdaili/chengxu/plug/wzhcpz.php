<?php

//写入你的完整域名,例如:baidu.com，不需要https或http
$dqurl = '你的域名';

//写入你的授权码
$shouquanma = '你的授权码';


?>
